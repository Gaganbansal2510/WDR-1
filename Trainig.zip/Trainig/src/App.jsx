import Faculty from "./Faculty.jsx";
function App(){
    return(
        <div>
            <Faculty facultyName = "Ramesh" subject = " Java" experience="13 years"/>
    </div>
  )
}
export default App;