import React, { useState } from "react";

function FacultyUpdate({ faculty, facultyData, setFacultyData, setUpdateFaculty }) {
  const [updated, setUpdated] = useState({ ...faculty });

  const handleUpdate = (e) => {
    e.preventDefault();

    const newData = facultyData.map((f) =>
      f.faculty_id === updated.faculty_id ? updated : f
    );

    setFacultyData(newData);
    alert("Faculty Updated!");
    setUpdateFaculty(null);
  };

  return (
    <div>
      <h2>Update Faculty</h2>

      <form onSubmit={handleUpdate}>
        <input
          value={updated.faculty_name}
          onChange={(e) =>
            setUpdated({ ...updated, faculty_name: e.target.value })
          }
        />

        <input
          type="number"
          value={updated.age}
          onChange={(e) =>
            setUpdated({ ...updated, age: e.target.value })
          }
        />

        <input
          value={updated.qualification}
          onChange={(e) =>
            setUpdated({ ...updated, qualification: e.target.value })
          }
        />

        <select
          value={updated.status}
          onChange={(e) =>
            setUpdated({ ...updated, status: e.target.value })
          }
        >
          <option value="active">active</option>
          <option value="left">left</option>
        </select>

        <button type="submit">Update</button>
      </form>

      <hr />
    </div>
  );
}

export default FacultyUpdate;
