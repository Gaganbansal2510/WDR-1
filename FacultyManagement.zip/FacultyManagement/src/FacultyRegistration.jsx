import React, { useState } from "react";

function FacultyRegistration({ facultyData, setFacultyData }) {
  const [input, setInput] = useState({
    faculty_id: "",
    faculty_name: "",
    age: "",
    qualification: "",
    joined_at: "",
    status: "active",
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    setFacultyData([...facultyData, input]);
    alert("Faculty Registered!");
    setInput({
      faculty_id: "",
      faculty_name: "",
      age: "",
      qualification: "",
      joined_at: "",
      status: "active",
    });
  };

  return (
    <div>
      <h2>Faculty Registration</h2>

      <form onSubmit={handleSubmit}>
        <input
          placeholder="Faculty ID"
          value={input.faculty_id}
          onChange={(e) =>
            setInput({ ...input, faculty_id: e.target.value })
          }
        />

        <input
          placeholder="Name"
          value={input.faculty_name}
          onChange={(e) =>
            setInput({ ...input, faculty_name: e.target.value })
          }
        />

        <input
          placeholder="Age"
          type="number"
          value={input.age}
          onChange={(e) =>
            setInput({ ...input, age: e.target.value })
          }
        />

        <input
          placeholder="Qualification"
          value={input.qualification}
          onChange={(e) =>
            setInput({ ...input, qualification: e.target.value })
          }
        />

        <input
          type="date"
          value={input.joined_at}
          onChange={(e) =>
            setInput({ ...input, joined_at: e.target.value })
          }
        />

        <button type="submit">Register</button>
      </form>
      <hr />
    </div>
  );
}

export default FacultyRegistration;
