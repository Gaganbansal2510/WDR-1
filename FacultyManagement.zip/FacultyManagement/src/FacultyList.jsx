import React from "react";

function FacultyList({ facultyData, setSelectedFaculty, setUpdateFaculty }) {
  return (
    <div>
      <h2>Faculty List</h2>

      {facultyData.length === 0 && <p>No faculty found.</p>}

      <ul>
        {facultyData.map((f) => (
          <li key={f.faculty_id}>
            {f.faculty_id} - {f.faculty_name} ({f.status})
            &nbsp;
            <button onClick={() => setSelectedFaculty(f)}>View</button>
            <button onClick={() => setUpdateFaculty(f)}>Update</button>
          </li>
        ))}
      </ul>

      <hr />
    </div>
  );
}

export default FacultyList;
