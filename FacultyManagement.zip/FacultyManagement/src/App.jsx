import React, { useState } from "react";
import FacultyRegistration from "./FacultyRegistration";
import FacultyList from "./FacultyList";
import FacultyProfile from "./FacultyProfile";
import FacultyUpdate from "./FacultyUpdate";

function App() {
  const [facultyData, setFacultyData] = useState([]);
  const [selectedFaculty, setSelectedFaculty] = useState(null);
  const [updateFaculty, setUpdateFaculty] = useState(null);

  return (
    <div style={{ padding: "20px" }}>
      <h1>Faculty Management System</h1>

      <FacultyRegistration
        facultyData={facultyData}
        setFacultyData={setFacultyData}
      />

      <FacultyList
        facultyData={facultyData}
        setSelectedFaculty={setSelectedFaculty}
        setUpdateFaculty={setUpdateFaculty}
      />

      {selectedFaculty && (
        <FacultyProfile faculty={selectedFaculty} />
      )}

      {updateFaculty && (
        <FacultyUpdate
          faculty={updateFaculty}
          facultyData={facultyData}
          setFacultyData={setFacultyData}
          setUpdateFaculty={setUpdateFaculty}
        />
      )}
    </div>
  );
}

export default App;
