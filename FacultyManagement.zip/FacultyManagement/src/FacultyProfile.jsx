import React from "react";

function FacultyProfile({ faculty }) {
  return (
    <div>
      <h2>Faculty Profile</h2>
      <p><b>ID:</b> {faculty.faculty_id}</p>
      <p><b>Name:</b> {faculty.faculty_name}</p>
      <p><b>Age:</b> {faculty.age}</p>
      <p><b>Qualification:</b> {faculty.qualification}</p>
      <p><b>Joined At:</b> {faculty.joined_at}</p>
      <p><b>Status:</b> {faculty.status}</p>

      <hr />
    </div>
  );
}

export default FacultyProfile;
