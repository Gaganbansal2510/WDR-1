function Sports(props) {
  return(
    <div>
    <h3> Player Name : {props.player}</h3>
    <h3>Age: {props.age}year</h3>
  </div>
  )
  
};

export default Sports;