import Student from "./Student.jsx";
// import './App.css';

function App() {
  return (
    <>
      <Student name="Aakash" age={18} />
    </>
  );
}

export default App;