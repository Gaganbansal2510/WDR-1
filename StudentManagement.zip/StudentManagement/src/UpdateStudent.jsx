import React, { useState } from 'react';

function UpdateStudent({ student, updateStudent }) {
  const [data, setData] = useState({ standard: student.standard, roll: student.roll });

  const handleChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    updateStudent(student.stid, data);
  };

  return (
    <div>
      <h3>Update Student</h3>
      <form onSubmit={handleSubmit}>
        <input name="standard" value={data.standard} onChange={handleChange} placeholder="Standard" />
        <input name="roll" value={data.roll} onChange={handleChange} placeholder="Roll No" />
        <button type="submit">Update</button>
      </form>
    </div>
  );
}

export default UpdateStudent;
