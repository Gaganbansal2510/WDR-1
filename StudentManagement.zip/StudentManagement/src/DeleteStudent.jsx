import React from 'react';

function DeleteStudent({ stid, deleteStudent }) {
  return (
    <div>
      <h3>Delete Student</h3>
      <button onClick={() => deleteStudent(stid)}>Delete</button>
    </div>
  );
}

export default DeleteStudent;
