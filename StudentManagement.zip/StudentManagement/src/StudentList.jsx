import React from 'react';

function StudentList({ students, onSelect }) {
  return (
    <div>
      <h2>All Students</h2>
      {students.length === 0 ? (
        <p>No students added yet.</p>
      ) : (
        <ul>
          {students.map((s) => (
            <li key={s.stid}>
              {s.stdname} (ID: {s.stid}) — Standard: {s.standard}
              <button onClick={() => onSelect(s)}>View</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default StudentList;
