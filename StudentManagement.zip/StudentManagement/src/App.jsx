import React, { useState } from 'react';
import StudentRegistration from './StudentRegistration';
import StudentList from './StudentList';
import StudentProfile from './StudentProfile';

function App() {
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);

  const addStudent = (student) => {
    setStudents([...students, student]);
  };

 

  return (
    <div style={{ padding: 20 }}>
      <h1> Student Management App</h1>

      <StudentRegistration addStudent={addStudent} />
      <hr />
      <StudentList students={students} onSelect={setSelectedStudent} />
      <hr />
      {selectedStudent && (
        <>
          <StudentProfile student={selectedStudent} />
          <UpdateStudent student={selectedStudent} updateStudent={updateStudent} />
         
        </>
      )}
    </div>
  );
}

export default App;
