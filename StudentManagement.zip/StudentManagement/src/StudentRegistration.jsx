import React, { useState } from 'react';

function StudentRegistration({ addStudent }) {
  const [student, setStudent] = useState({
    stid: '',
    stdname: '',
    standard: '',
    age: '',
    roll: '',
  });

  const handleChange = (e) => {
    setStudent({ ...student, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    addStudent(student);
    setStudent({ stid: '', stdname: '', standard: '', age: '', roll: '' });
  };

  return (
    <div>
      <h2>Register Student</h2>
      <form onSubmit={handleSubmit}>
        <input name="stid" placeholder="Student ID" value={student.stid} onChange={handleChange} required />
        <input name="stdname" placeholder="Name" value={student.stdname} onChange={handleChange} required />
        <input name="standard" placeholder="Standard" value={student.standard} onChange={handleChange} required />
        <input name="age" placeholder="Age" value={student.age} onChange={handleChange} required />
        <input name="roll" placeholder="Roll No" value={student.roll} onChange={handleChange} required />
        <button type="submit">Add Student</button>
      </form>
    </div>
  );
}

export default StudentRegistration;
