import React, { useState } from "react";

function CourseUpdate({ course, courses, setCourses, setCourseToUpdate }) {
  const [updated, setUpdated] = useState({ ...course });

  const handleUpdate = (e) => {
    e.preventDefault();

    const newData = courses.map((c) =>
      c.courseid === updated.courseid ? updated : c
    );

    setCourses(newData);
    alert("Course Updated!");
    setCourseToUpdate(null);
  };

  return (
    <div>
      <h2>Update Course</h2>

      <form onSubmit={handleUpdate}>
        <input value={updated.coursename} onChange={(e)=> setUpdated({...updated, coursename:e.target.value})}/>
        <textarea value={updated.description} onChange={(e)=> setUpdated({...updated, description:e.target.value})}/>
        <input type="number" value={updated.duration_in_hours} onChange={(e)=> setUpdated({...updated, duration_in_hours:e.target.value})}/>
        <input type="number" value={updated.min_enrollment} onChange={(e)=> setUpdated({...updated, min_enrollment:e.target.value})}/>
        <input type="number" value={updated.max_enrollment} onChange={(e)=> setUpdated({...updated, max_enrollment:e.target.value})}/>
        <input type="date" value={updated.created_or_updated} onChange={(e)=> setUpdated({...updated, created_or_updated:e.target.value})}/>
        <button type="submit">Update</button>
      </form>

      <hr />
    </div>
  );
}

export default CourseUpdate;
