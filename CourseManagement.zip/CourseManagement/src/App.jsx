import React, { useState } from "react";
import CourseRegistration from "./CourseRegistration";
import CourseList from "./CourseList";
import CourseDetails from "./CourseDetails";
import CourseUpdate from "./CourseUpdate";
//port ModuleCreation from "./components/ModuleCreation";
//port FacultyAlignment from "./components/FacultyAlignment";

function App() {
  const [courses, setCourses] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [courseToUpdate, setCourseToUpdate] = useState(null);

  return (
    <div style={{ padding: "20px" }}>
      <h1>LMS - Course Management Module</h1>

      <CourseRegistration courses={courses} setCourses={setCourses} />

      <CourseList
        courses={courses}
        setSelectedCourse={setSelectedCourse}
        setCourseToUpdate={setCourseToUpdate}
        setCourses={setCourses}
      />

      {selectedCourse && (
        <CourseDetails course={selectedCourse} />
      )}

      {courseToUpdate && (
        <CourseUpdate
          course={courseToUpdate}
          courses={courses}
          setCourses={setCourses}
          setCourseToUpdate={setCourseToUpdate}
        />
      )}

      {selectedCourse && (
        <>
          <ModuleCreation
            course={selectedCourse}
            courses={courses}
            setCourses={setCourses}
          />

          <FacultyAlignment
            course={selectedCourse}
            courses={courses}
            setCourses={setCourses}
          />
        </>
      )}
    </div>
  );
}

export default App;
