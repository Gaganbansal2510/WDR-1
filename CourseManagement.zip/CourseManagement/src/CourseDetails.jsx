import React from "react";

function CourseDetails({ course }) {
  return (
    <div>
      <h2>Course Details</h2>

      <p><b>ID:</b> {course.courseid}</p>
      <p><b>Name:</b> {course.coursename}</p>
      <p><b>Description:</b> {course.description}</p>
      <p><b>Duration:</b> {course.duration_in_hours} hours</p>
      <p><b>Min Enrollment:</b> {course.min_enrollment}</p>
      <p><b>Max Enrollment:</b> {course.max_enrollment}</p>
      <p><b>Date:</b> {course.created_or_updated}</p>

      <p><b>Assigned Faculty:</b> {course.faculty || "None"}</p>

      <h3>Modules</h3>
      {course.modules.length === 0 && <p>No modules added.</p>}
      <ul>
        {course.modules.map((m,i)=> <li key={i}>{m}</li>)}
      </ul>

      <hr />
    </div>
  );
}

export default CourseDetails;
