import React, { useState } from "react";

function CourseRegistration({ courses, setCourses }) {
  const [course, setCourse] = useState({
    courseid: "",
    coursename: "",
    description: "",
    duration_in_hours: "",
    min_enrollment: "",
    max_enrollment: "",
    created_or_updated: "",
    modules: [],
    faculty: ""
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    setCourses([...courses, course]);
    alert("Course Registered!");
  };

  return (
    <div>
      <h2>Course Registration</h2>

      <form onSubmit={handleSubmit}>
        <input placeholder="Course ID" onChange={(e)=> setCourse({...course, courseid:e.target.value})}/>
        
        <input placeholder="Course Name" onChange={(e)=> setCourse({...course, coursename:e.target.value})}/>

        <textarea placeholder="Description" onChange={(e)=> setCourse({...course, description:e.target.value})}/>

        <input type="number" placeholder="Duration (hours)" onChange={(e)=> setCourse({...course, duration_in_hours:e.target.value})}/>

        <input type="number" placeholder="Min Enrollment" onChange={(e)=> setCourse({...course, min_enrollment:e.target.value})}/>

        <input type="number" placeholder="Max Enrollment" onChange={(e)=> setCourse({...course, max_enrollment:e.target.value})}/>

        <input type="date" onChange={(e)=> setCourse({...course, created_or_updated:e.target.value})}/>

        <button type="submit">Register</button>
      </form>

      <hr />
    </div>
  );
}

export default CourseRegistration;
