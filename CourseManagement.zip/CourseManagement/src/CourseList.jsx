import React from "react";

function CourseList({ courses, setSelectedCourse, setCourseToUpdate, setCourses }) {
  
  const deleteCourse = (id) => {
    setCourses(courses.filter(c => c.courseid !== id));
    alert("Course Deleted");
  };

  return (
    <div>
      <h2>Course List</h2>

      {courses.length === 0 && <p>No courses available.</p>}

      <ul>
        {courses.map((c) => (
          <li key={c.courseid}>
            {c.coursename} ({c.courseid})
            <button onClick={() => setSelectedCourse(c)}>Details</button>
            <button onClick={() => setCourseToUpdate(c)}>Update</button>
            <button onClick={() => deleteCourse(c.courseid)}>Delete</button>
          </li>
        ))}
      </ul>

      <hr />
    </div>
  );
}

export default CourseList;
