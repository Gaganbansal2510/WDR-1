import React from 'react'

const course_update = () => {
  return (
    <div>
      Course Update
    </div>
  )
}

export default course_update
