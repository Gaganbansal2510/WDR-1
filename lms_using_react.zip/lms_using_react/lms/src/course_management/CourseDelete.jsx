import React from 'react'

const course_delete = () => {
  return (
    <div>
      Course Delete
    </div>
  )
}

export default course_delete
