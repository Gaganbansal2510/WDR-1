import React from 'react'

const course_creation = () => {
  return (
    <div>
      Course Created
    </div>
  )
}

export default course_creation
