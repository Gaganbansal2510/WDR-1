import React from 'react'

const course_details = () => {
  return (
    <div>
      Course Details
    </div>
  )
}

export default course_details
