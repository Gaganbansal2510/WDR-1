import React from 'react'

const course_registration = () => {
  return (
    <div>
        
    </div>
  )
}

export default course_registration
